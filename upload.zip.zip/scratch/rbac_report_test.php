<?php
declare(strict_types=1);

require_once 'C:/xampp/htdocs/VINJACK-PHP/api/config/Database.php';
require_once 'C:/xampp/htdocs/VINJACK-PHP/api/core/JWT.php';

use Core\JWT;

echo "=================================================\n";
echo "TESTING REPORTCONTROLLER RBAC PERMISSION CHECKS\n";
echo "=================================================\n\n";

function testEndpoint(string $endpoint, string $token): array {
    $url = "http://localhost/VINJACK-PHP/api/{$endpoint}";
    $opts = [
        'http' => [
            'method' => 'GET',
            'header' => "Authorization: Bearer {$token}\r\nAccept: application/json\r\n",
            'ignore_errors' => true
        ]
    ];
    $ctx = stream_context_create($opts);
    $response = file_get_contents($url, false, $ctx);
    $statusLine = $http_response_header[0] ?? 'HTTP/Unknown';
    preg_match('{HTTP\/\S*\s(\d{3})}', $statusLine, $m);
    $statusCode = (int)($m[1] ?? 500);

    return [
        'code' => $statusCode,
        'body' => json_decode($response, true)
    ];
}

// 1. Super Admin Token (Bypasses RBAC)
$superAdminToken = JWT::encode([
    'id' => 1,
    'username' => 'admin',
    'full_name' => 'Super Administrator',
    'role' => 'Super Admin',
    'permissions' => []
], JWT::getDefaultSecret(), 3600);

// 2. Salesperson Token (Only has canViewDashboard, NOT canViewReports)
$salespersonToken = JWT::encode([
    'id' => 3,
    'username' => 'sales_rep',
    'full_name' => 'Sales Person',
    'role' => 'Salesperson',
    'permissions' => ['canViewDashboard', 'canManageSales']
], JWT::getDefaultSecret(), 3600);

// 3. Admin Token (Has canViewReports)
$adminToken = JWT::encode([
    'id' => 2,
    'username' => 'manager',
    'full_name' => 'Shop Manager',
    'role' => 'Admin',
    'permissions' => ['canViewReports']
], JWT::getDefaultSecret(), 3600);

// 4. Unauthorized Token (Lacks canViewDashboard and canViewReports)
$unauthorizedToken = JWT::encode([
    'id' => 4,
    'username' => 'guest',
    'full_name' => 'Guest User',
    'role' => 'Guest',
    'permissions' => ['canViewInventory']
], JWT::getDefaultSecret(), 3600);

echo "[TEST 1] Super Admin Access (Bypasses checks):\n";
$r1 = testEndpoint('reports/dashboard', $superAdminToken);
echo "  - GET reports/dashboard: HTTP {$r1['code']} (Expected: 200)\n";
assert($r1['code'] === 200, "Super admin should access dashboard");

$r2 = testEndpoint('reports/top-selling', $superAdminToken);
echo "  - GET reports/top-selling: HTTP {$r2['code']} (Expected: 200)\n";
assert($r2['code'] === 200, "Super admin should access top-selling");
echo "  ==> PASS: Super Admin\n\n";

echo "[TEST 2] Salesperson Access (has 'canViewDashboard'):\n";
$r3 = testEndpoint('reports/dashboard', $salespersonToken);
echo "  - GET reports/dashboard: HTTP {$r3['code']} (Expected: 200)\n";
assert($r3['code'] === 200, "Salesperson with canViewDashboard should access dashboard");

$r4 = testEndpoint('reports/top-selling', $salespersonToken);
echo "  - GET reports/top-selling: HTTP {$r4['code']} (Expected: 200)\n";
assert($r4['code'] === 200, "Salesperson with canViewDashboard should access top-selling widget");
echo "  ==> PASS: Salesperson with canViewDashboard\n\n";

echo "[TEST 3] Manager Access (has 'canViewReports'):\n";
$r5 = testEndpoint('reports/dashboard', $adminToken);
echo "  - GET reports/dashboard: HTTP {$r5['code']} (Expected: 200)\n";
assert($r5['code'] === 200, "User with canViewReports should access dashboard");

$r6 = testEndpoint('reports/top-selling', $adminToken);
echo "  - GET reports/top-selling: HTTP {$r6['code']} (Expected: 200)\n";
assert($r6['code'] === 200, "User with canViewReports should access top-selling widget");
echo "  ==> PASS: User with canViewReports\n\n";

echo "[TEST 4] Unauthorized Access (Lacks both permissions):\n";
$r7 = testEndpoint('reports/dashboard', $unauthorizedToken);
echo "  - GET reports/dashboard: HTTP {$r7['code']} (Expected: 403)\n";
assert($r7['code'] === 403, "Unauthorized user should be blocked from dashboard");

$r8 = testEndpoint('reports/top-selling', $unauthorizedToken);
echo "  - GET reports/top-selling: HTTP {$r8['code']} (Expected: 403)\n";
assert($r8['code'] === 403, "Unauthorized user should be blocked from top-selling");
echo "  ==> PASS: Unauthorized user blocked with 403\n\n";

echo "=================================================\n";
echo "ALL PERMISSION TESTS PASSED SUCCESSFULLY!\n";
echo "=================================================\n";
