<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../../xampp/htdocs/VINJACK-PHP/api/config/Database.php';
require_once __DIR__ . '/../../../../xampp/htdocs/VINJACK-PHP/api/models/SaleDAO.php';
require_once __DIR__ . '/../../../../xampp/htdocs/VINJACK-PHP/api/models/PurchaseOrderDAO.php';
require_once __DIR__ . '/../../../../xampp/htdocs/VINJACK-PHP/api/models/ProductDAO.php';

echo "=== VINJACK MOTORWORKS PHASE 3 VERIFICATION TEST ===\n\n";

try {
    $conn = Database::getConnection();
    echo "[OK] Connected to Database successfully.\n";

    // 1. Verify Products and Suppliers
    $productStmt = $conn->query("SELECT id, name, item_code, quantity, default_cost, price, consigned_stock FROM products LIMIT 2");
    $products = $productStmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($products)) {
        echo "[INFO] No products found. Seeding a sample product for testing...\n";
        $conn->exec("
            INSERT INTO products (item_code, name, category_id, brand_id, price, default_cost, quantity, consigned_stock, stock_status)
            VALUES ('TEST-SKU-001', 'High-Performance Test Brake Pad', 2, 2, 850.00, 450.00, 20, 5, 'Healthy')
        ");
        $products = $conn->query("SELECT id, name, item_code, quantity, default_cost, price, consigned_stock FROM products WHERE item_code = 'TEST-SKU-001'")->fetchAll(PDO::FETCH_ASSOC);
    }

    $prod1 = $products[0];
    echo "[INFO] Using Product ID {$prod1['id']}: '{$prod1['name']}', Stock: {$prod1['quantity']}, Consigned: {$prod1['consigned_stock']}\n";

    // 2. Test SaleDAO::createSale
    echo "\n--- TESTING SaleDAO::createSale ---\n";
    $saleDAO = new SaleDAO();

    $saleData = [
        'customer_id'   => null,
        'motorcycle_id' => null,
        'tax_rate'      => 0.00
    ];

    $items = [
        [
            'product_id'    => (int)$prod1['id'],
            'quantity'      => 2,
            'price_at_time' => (float)$prod1['price']
        ]
    ];

    $services = [
        [
            'service_id'    => 1,
            'price_at_time' => 250.00
        ]
    ];

    $initialStock = (int)$prod1['quantity'];
    $saleId = $saleDAO->createSale($saleData, $items, $services, 1);
    echo "[PASS] createSale executed successfully! Generated Sale ID: {$saleId}\n";

    // Verify stock deduction
    $checkProd = $conn->query("SELECT quantity, stock_status FROM products WHERE id = {$prod1['id']}")->fetch(PDO::FETCH_ASSOC);
    echo "[PASS] Product stock changed from {$initialStock} to {$checkProd['quantity']} (Stock Status: {$checkProd['stock_status']})\n";

    // Verify movements table
    $movCheck = $conn->query("SELECT * FROM movements WHERE reference_id = 'REC-{$saleId}' AND type = 'SALE'")->fetch(PDO::FETCH_ASSOC);
    if ($movCheck) {
        echo "[PASS] Movement audit record logged: {$movCheck['type']}, Qty Change: {$movCheck['quantity_change']}, Stock: {$movCheck['stock_before']} -> {$movCheck['stock_after']}\n";
    } else {
        echo "[FAIL] Movement audit record not found for sale REC-{$saleId}!\n";
    }

    // 3. Test SaleDAO::getReceiptXml
    echo "\n--- TESTING SaleDAO::getReceiptXml ---\n";
    $xmlReceipt = $saleDAO->getReceiptXml($saleId);
    echo "[PASS] Generated Receipt XML length: " . strlen($xmlReceipt) . " bytes\n";

    // Validate XML with DOMDocument
    $dom = new DOMDocument();
    $validXml = $dom->loadXML($xmlReceipt);
    if ($validXml) {
        echo "[PASS] Receipt XML is well-formed and valid!\n";
        echo "Root Element: " . $dom->documentElement->tagName . " (ID: " . $dom->documentElement->getAttribute('id') . ")\n";
        $headerName = $dom->getElementsByTagName('company_name')->item(0)->textContent ?? '';
        echo "Company: {$headerName}\n";
        $grandTotal = $dom->getElementsByTagName('grand_total')->item(0)->textContent ?? '';
        echo "Grand Total: ₱{$grandTotal}\n";
    } else {
        echo "[FAIL] Receipt XML failed XML schema parsing!\n";
    }

    // 4. Test PurchaseOrderDAO::createPurchaseOrder
    echo "\n--- TESTING PurchaseOrderDAO::createPurchaseOrder ---\n";
    $poDAO = new PurchaseOrderDAO();

    $sup = $conn->query("SELECT id, name FROM suppliers LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    if (!$sup) {
        $conn->exec("INSERT INTO suppliers (name, status, default_payment_terms) VALUES ('Test Supplier Phils', 'Approved', 'Terms')");
        $sup = $conn->query("SELECT id, name FROM suppliers WHERE name = 'Test Supplier Phils'")->fetch(PDO::FETCH_ASSOC);
    }

    $poData = [
        'supplier_id'          => (int)$sup['id'],
        'po_type'              => 'Purchase',
        'consignment_method'   => 'System',
        'terms_and_conditions' => 'Net 30 Days',
        'notes'                => 'Phase 3 Verification PO',
        'items'                => [
            [
                'product_id' => (int)$prod1['id'],
                'quantity'   => 10,
                'cost'       => (float)$prod1['default_cost'] ?: 450.00
            ]
        ]
    ];

    $poId = $poDAO->createPurchaseOrder($poData, 1);
    echo "[PASS] createPurchaseOrder executed successfully! Generated PO ID: {$poId}\n";

    $poDetails = $poDAO->getPurchaseOrderById($poId);
    echo "[PASS] PO Number: {$poDetails['po_number']}, Status: {$poDetails['status']}, Total: ₱" . number_format((float)$poDetails['total_amount'], 2) . "\n";

    // 5. Test PurchaseOrderDAO::receiveOrderItems
    echo "\n--- TESTING PurchaseOrderDAO::receiveOrderItems ---\n";
    $recItems = [
        [
            'product_id'        => (int)$prod1['id'],
            'quantity_received' => 5
        ]
    ];

    $beforeReceiveStock = (int)$conn->query("SELECT quantity FROM products WHERE id = {$prod1['id']}")->fetchColumn();
    $updatedPo = $poDAO->receiveOrderItems($poId, $recItems, 1);
    $afterReceiveStock = (int)$conn->query("SELECT quantity FROM products WHERE id = {$prod1['id']}")->fetchColumn();

    echo "[PASS] receiveOrderItems committed! Stock before: {$beforeReceiveStock}, Stock after: {$afterReceiveStock} (+5 units)\n";
    echo "[PASS] PO Status transitioned to: '{$updatedPo['status']}' (Partially Received)\n";

    // Verify PO Delivery movement
    $poMovCheck = $conn->query("SELECT * FROM movements WHERE reference_id = '{$poDetails['po_number']}' AND type = 'DELIVERY (PO)'")->fetch(PDO::FETCH_ASSOC);
    if ($poMovCheck) {
        echo "[PASS] Movement audit record logged: {$poMovCheck['type']}, Qty Change: +{$poMovCheck['quantity_change']}, Stock: {$poMovCheck['stock_before']} -> {$poMovCheck['stock_after']}\n";
    } else {
        echo "[FAIL] Movement audit record not found for PO delivery!\n";
    }

    // 6. Test PurchaseOrderDAO::getExportXml
    echo "\n--- TESTING PurchaseOrderDAO::getExportXml ---\n";
    $poXml = $poDAO->getExportXml($poId);
    echo "[PASS] Generated PO Export XML length: " . strlen($poXml) . " bytes\n";

    $poDom = new DOMDocument();
    $poValid = $poDom->loadXML($poXml);
    if ($poValid) {
        echo "[PASS] PO Export XML is well-formed and valid!\n";
        echo "Root Element: " . $poDom->documentElement->tagName . " (PO#: " . $poDom->documentElement->getAttribute('po_number') . ")\n";
        $vendorName = $poDom->getElementsByTagName('supplier')->item(0)->getElementsByTagName('name')->item(0)->textContent ?? '';
        echo "Supplier Name in XML: {$vendorName}\n";
        $lineItemCount = $poDom->getElementsByTagName('line_items')->item(0)->getAttribute('count') ?? '0';
        echo "Line Items count: {$lineItemCount}\n";
    } else {
        echo "[FAIL] PO Export XML failed XML schema parsing!\n";
    }

    echo "\n=== ALL PHASE 3 VERIFICATION TESTS PASSED SUCCESSFULLY! ===\n";

} catch (Throwable $e) {
    echo "\n[ERROR] Test failed with exception:\n" . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n";
    exit(1);
}
