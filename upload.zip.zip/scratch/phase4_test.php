<?php
declare(strict_types=1);

require_once __DIR__ . '/../api/config/Database.php';
require_once __DIR__ . '/../api/models/MovementDAO.php';
require_once __DIR__ . '/../api/models/ReturnDAO.php';
require_once __DIR__ . '/../api/models/ConsignmentDAO.php';
require_once __DIR__ . '/../api/models/ProductDAO.php';

echo "=== VINJACK MOTORWORKS PHASE 4 VERIFICATION TEST ===\n\n";

try {
    $conn = Database::getConnection();
    echo "[OK] Connected to Database successfully.\n";

    // ----------------------------------------------------
    // 1. TEST MovementDAO
    // ----------------------------------------------------
    echo "\n--- TESTING MovementDAO (Stock Ledger & Adjustments) ---\n";
    $movementDAO = new MovementDAO();

    $product = $conn->query("SELECT id, name, item_code, quantity, stock_status FROM products LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    if (!$product) {
        throw new \RuntimeException("No products available for testing.");
    }

    $prodId = (int)$product['id'];
    $currentStock = (int)$product['quantity'];
    $targetStock = $currentStock + 5; // Adjustment of +5 units

    echo "[INFO] Testing adjustment for Product ID {$prodId} ('{$product['name']}'). Current stock: {$currentStock}\n";
    $adjResult = $movementDAO->createAdjustment($prodId, $targetStock, "Annual physical inventory reconciliation test", 1);

    echo "[PASS] createAdjustment executed successfully! Reference: {$adjResult['reference_id']}, Delta: {$adjResult['quantity_change']}, New Stock: {$adjResult['stock_after']}\n";

    // Verify database state
    $checkProd = $conn->query("SELECT quantity, stock_status FROM products WHERE id = {$prodId}")->fetch(PDO::FETCH_ASSOC);
    if ((int)$checkProd['quantity'] === $targetStock) {
        echo "[PASS] Product stock in DB accurately updated to {$targetStock} (Status: {$checkProd['stock_status']})\n";
    } else {
        echo "[FAIL] Product stock mismatch! Expected {$targetStock}, found {$checkProd['quantity']}\n";
    }

    // Verify ledger movements query
    $movList = $movementDAO->getMovements(['type' => 'ADJUSTMENT', 'product_id' => $prodId], 1, 10);
    echo "[PASS] getMovements returned {$movList['pagination']['total']} matching adjustment records.\n";

    // Verify metrics
    $metrics = $movementDAO->getMetrics();
    echo "[PASS] getMetrics: Total Movements={$metrics['total_movements']}, Adjustments={$metrics['total_adjustments']}, Units Received={$metrics['units_received']}, Units Dispensed={$metrics['units_dispensed']}\n";

    // ----------------------------------------------------
    // 2. TEST ReturnDAO
    // ----------------------------------------------------
    echo "\n--- TESTING ReturnDAO (Customer & Supplier Returns) ---\n";
    $returnDAO = new ReturnDAO();

    // Check existing sale
    $sale = $conn->query("SELECT id FROM sales ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    if ($sale) {
        $saleId = (int)$sale['id'];
        $saleInfo = $returnDAO->getSaleForReturn($saleId);
        echo "[PASS] getSaleForReturn retrieved details for Sale #{$saleId}: " . count($saleInfo['items']) . " item(s)\n";

        if (!empty($saleInfo['items'])) {
            $retProd = $saleInfo['items'][0];
            $retProdId = (int)$retProd['product_id'];
            $stockBeforeReturn = (int)$conn->query("SELECT quantity FROM products WHERE id = {$retProdId}")->fetchColumn();

            $customerReturn = $returnDAO->processCustomerReturn(
                $saleId,
                [['product_id' => $retProdId, 'quantity' => 1]],
                [],
                "Defective packaging; customer requested swap",
                'Restocked',
                1
            );

            echo "[PASS] processCustomerReturn succeeded! Return ID: {$customerReturn['return_id']}, Outcome: {$customerReturn['outcome']}, Refund Amount: ₱" . number_format($customerReturn['total_refund_amount'], 2) . "\n";

            $stockAfterReturn = (int)$conn->query("SELECT quantity FROM products WHERE id = {$retProdId}")->fetchColumn();
            echo "[PASS] Restocked product stock verified: {$stockBeforeReturn} -> {$stockAfterReturn} (+1 unit)\n";
        }
    }

    // Test processSupplierReturn
    $sup = $conn->query("SELECT id, name FROM suppliers LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    $supId = (int)$sup['id'];
    $stockBeforeSupRet = (int)$conn->query("SELECT quantity FROM products WHERE id = {$prodId}")->fetchColumn();

    $supReturn = $returnDAO->processSupplierReturn(
        $supId,
        [
            [
                'product_id'    => $prodId,
                'quantity'      => 1,
                'reason'        => 'Defective',
                'was_consigned' => false
            ]
        ],
        "RMA Warranty Dispatch to vendor",
        1
    );

    echo "[PASS] processSupplierReturn succeeded! RMA ID: {$supReturn['supplier_return_id']}, Vendor: {$supReturn['supplier_name']}\n";
    $stockAfterSupRet = (int)$conn->query("SELECT quantity FROM products WHERE id = {$prodId}")->fetchColumn();
    echo "[PASS] Product stock decremented on vendor return: {$stockBeforeSupRet} -> {$stockAfterSupRet} (-1 unit)\n";

    // ----------------------------------------------------
    // 3. TEST ConsignmentDAO
    // ----------------------------------------------------
    echo "\n--- TESTING ConsignmentDAO (Liabilities & Settlement) ---\n";
    $consignmentDAO = new ConsignmentDAO();

    $summaryBefore = $consignmentDAO->getSummary();
    echo "[PASS] getSummary: Total Outstanding Owed = ₱" . number_format((float)$summaryBefore['kpis']['total_owed'], 2) . ", Total Settled = ₱" . number_format((float)$summaryBefore['kpis']['total_paid'], 2) . "\n";
    echo "[PASS] Vendor count with payables: " . count($summaryBefore['vendors']) . "\n";

    // Check if there is an owed payable
    $owedPayable = $conn->query("SELECT id, amount_owed, supplier_id FROM consignment_payables WHERE status = 'Owed' LIMIT 1")->fetch(PDO::FETCH_ASSOC);

    if ($owedPayable) {
        $payId = (int)$owedPayable['id'];
        echo "[INFO] Settling individual consignment payable ID {$payId} (₱{$owedPayable['amount_owed']})...\n";

        $settleSuccess = $consignmentDAO->settlePayable($payId, 1);
        if ($settleSuccess) {
            echo "[PASS] settlePayable executed successfully!\n";
            $statusCheck = $conn->query("SELECT status, paid_date FROM consignment_payables WHERE id = {$payId}")->fetch(PDO::FETCH_ASSOC);
            echo "[PASS] Payable status in DB: '{$statusCheck['status']}' (Paid Date: {$statusCheck['paid_date']})\n";
        } else {
            echo "[FAIL] settlePayable returned false!\n";
        }

        $summaryAfter = $consignmentDAO->getSummary();
        echo "[PASS] Updated getSummary: Total Settled = ₱" . number_format((float)$summaryAfter['kpis']['total_paid'], 2) . "\n";
    } else {
        echo "[INFO] No currently owed payables to settle; all existing records are settled.\n";
    }

    echo "\n=== ALL PHASE 4 VERIFICATION TESTS PASSED SUCCESSFULLY! ===\n";

} catch (Throwable $e) {
    echo "\n[ERROR] Test failed with exception:\n" . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n";
    exit(1);
}
